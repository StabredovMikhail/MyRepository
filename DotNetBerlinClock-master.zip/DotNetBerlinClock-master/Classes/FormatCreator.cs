﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BerlinClock
{
    public class FormatCreator : IFormatCreator
    {
        public ITimeConverter GetFormatObject(string format)
        {
            switch (format)
            {
                case "1": return new TimeConverter();
                case "2": return new TimeConverter();
                case "3": return new ReverseTimeConverter();
                default: throw new NotImplementedException();
            }
        }
    }
}
