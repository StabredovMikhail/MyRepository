﻿using System;

namespace BerlinClock
{
    public class Time
    {
        private int _hours;
        private int _minutes;
        private int _seconds;

        public Time()
        {

        }

        public Time(string time)
        {
            string[] timeValues = time.Split(new string[] { ":" }, StringSplitOptions.None);
            Hours = Int32.Parse(timeValues[0]);
            Minutes = Int32.Parse(timeValues[1]);
            Seconds = Int32.Parse(timeValues[2]);
        }

        public Time (DateTime dateTime)
        {
            Hours = dateTime.Hour;
            Minutes = dateTime.Minute;
            Seconds = dateTime.Second;
        }

        public int Hours
        {
            get => _hours;
            set => _hours = value;
        }
        public int Minutes
        {
            get => _minutes;
            set => _minutes = value;
        }
        public int Seconds
        {
            get => _seconds;
            set => _seconds = value;
        }

        public override string ToString()
        {
            return string.Format("{0}:{1}", Hours, Minutes);
        }
    }
}
