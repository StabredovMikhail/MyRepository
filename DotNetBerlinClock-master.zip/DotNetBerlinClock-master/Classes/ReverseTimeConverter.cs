﻿using System;
using System.Linq;

namespace BerlinClock
{
    public class ReverseTimeConverter : ITimeConverter
    {
        public string convertTime(string aTime)
        {
            return GetNormalTime(aTime);
        }

        /// <summary>
        /// Get time by BerlinClockTime
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private string GetNormalTime(string berlinClockTime)
        {
            Time time = new Time();
            var split = berlinClockTime.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
            if (split.Count() < 5)
                throw new Exception("Error");

            time.Hours = (split[1].Count(c => c != Colors.ColorOff) * 5) +
                split[2].Count(c => c != Colors.ColorOff);

            time.Minutes = (split[3].Count(c => c != Colors.ColorOff) * 5) +
                split[4].Count(c => c != Colors.ColorOff);

            return time.ToString();
        }
    }
}
