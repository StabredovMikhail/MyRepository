﻿namespace BerlinClock
{
    public interface IFormatCreator
    {
        ITimeConverter GetFormatObject(string format);
    }
}
