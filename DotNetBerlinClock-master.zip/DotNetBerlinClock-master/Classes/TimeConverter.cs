﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BerlinClock
{
    public struct Colors
    {
        public const char Yellow = 'Y';
        public const char Red = 'R';
        public const char ColorOff = 'O';
    }

    public class TimeConverter : ITimeConverter
    {
        public string convertTime(string aTime)
        {
            Time time = new Time(aTime);
            var result = GetBerlinClockTime(time);
            return result;
        }

        /// <summary>
        /// Get BerlinClockTime by time
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        private string GetBerlinClockTime(Time time)
        {
            var seconds = GetSeconds(time.Seconds % 2);
            var minutes = FormBlock(new string[] { GetMinutesFirstPart(time.Minutes / 5), GetMinutesSecondPart(time.Minutes % 5) });
            var hours = FormBlock(new string[] { GetHours(time.Hours / 5), GetHours(time.Hours % 5) });
            var result = FormBlock(new string[] { seconds, hours, minutes });
            return result;
        }

        private string FormBlock(string[] values)
        {
            return string.Join(Environment.NewLine, values);
        }

        private string GetHours(int value)
        {
            string hours = string.Empty;
            for (int i = 0; i < 4; i++)
                hours += (value > i) ? Colors.Red : Colors.ColorOff;
            return hours;
        }

        private string GetMinutesFirstPart(int value)
        {
            string minutes = string.Empty;
            for (int i = 1; i <= 11; i++)
            {
                if (value >= i && i % 3 == 0)
                    minutes += Colors.Red;
                else if (value >= i)
                    minutes += Colors.Yellow;
                else
                    minutes += Colors.ColorOff;
            }
            return minutes;
        }

        private string GetMinutesSecondPart(int value)
        {
            string minutes = string.Empty;
            for (int i = 0; i < 4; i++)
                minutes += (value > i) ? Colors.Yellow : Colors.ColorOff;
            return minutes;
        }

        private string GetSeconds(int value)
        {
            return (value == 0) ? Colors.Yellow.ToString() : Colors.ColorOff.ToString();
        }
    }
}
