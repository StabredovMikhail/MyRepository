﻿using BerlinClock;
using System;
using System.Threading;

namespace BerlinClockConsoleApp
{
    class Program
    {
        private const string testString = "O\r\nRROO\r\nRRRO\r\nYYROOOOOOOO\r\nYYOO";

        static void Main(string[] args)
        {
            try
            {
                IFormatCreator factory = new FormatCreator();
                Console.WriteLine("Conversion type:\n1. Show converted value (time to BerlinClock) \n2. Show current time \n3.Test line to time: \n" + testString);
                Console.Write("№ ");
                string operation = Console.ReadLine();
                ITimeConverter converter = factory.GetFormatObject(operation);
                switch (operation)
                {
                    case "1":
                        Console.WriteLine("Enter Time (hh:mm:ss):");
                        string inputDate = Console.ReadLine();
                        GetData(inputDate, converter);
                        break;
                    case "2":
                        Timer t = new Timer(TimerCallback, converter, 0, 1000);
                        break;
                    case "3":
                        Console.WriteLine(converter.convertTime(testString));
                        break;
                    default: return;
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadLine();
        }

        private static void GetData(string value, ITimeConverter converter)
        {
            Console.Clear();
            var berlinClockTime = converter.convertTime(value);
            Console.WriteLine(berlinClockTime);
        }

        private static void TimerCallback(object obj)
        {
            var dt = DateTime.Now;
            string value = string.Format("{0}:{1}:{2}", dt.Hour, dt.Minute, dt.Second);
            GetData(value, (ITimeConverter)obj);
        }
    }
}
